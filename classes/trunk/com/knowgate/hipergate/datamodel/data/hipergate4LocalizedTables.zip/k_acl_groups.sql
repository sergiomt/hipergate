﻿INSERT INTO k_acl_groups (gu_acl_group,id_domain,bo_active,nm_acl_group,de_acl_group) VALUES ('ce75c69a786f49cfa3beead8a961942c',1024,1,'SYSTEM / Administrators','Members can fully administrate domain');

INSERT INTO k_acl_groups (gu_acl_group,id_domain,bo_active,nm_acl_group,de_acl_group) VALUES ('0fb03429fa3447a6be92142479fc6d52',1025,1,'MODEL / Administrators','Members can fully administrate domain');
INSERT INTO k_acl_groups (gu_acl_group,id_domain,bo_active,nm_acl_group,de_acl_group) VALUES ('c0a80146f4cc507f0e10021acf4aad60',1025,1,'MODEL / Power Users','Members may access domain but cannot change its configuration');
INSERT INTO k_acl_groups (gu_acl_group,id_domain,bo_active,nm_acl_group,de_acl_group) VALUES ('c0a80146f4cc55e5d710021bc3e3ed97',1025,1,'MODEL / Users','Members may access domain but cannot change its configuration');
INSERT INTO k_acl_groups (gu_acl_group,id_domain,bo_active,nm_acl_group,de_acl_group) VALUES ('c0a80146f4cc57e3cb10021c8d0629bc',1025,1,'MODEL / Guest','Members have only the minimum priviledges on domain');
