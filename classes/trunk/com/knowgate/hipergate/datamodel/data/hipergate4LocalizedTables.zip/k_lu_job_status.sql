﻿INSERT INTO k_lu_job_status (id_status,tr_en,tr_es,tr_fr,tr_de,tr_it,tr_u1,tr_u2,tr_u3,tr_u4,tr_ru) VALUES (-1,'Cancelled','Cancelado','Annulé',NULL,'Cancellato',NULL,NULL,NULL,NULL,'Отменён');
INSERT INTO k_lu_job_status (id_status,tr_en,tr_es,tr_fr,tr_de,tr_it,tr_u1,tr_u2,tr_u3,tr_u4,tr_ru) VALUES (0,'Finished','Terminado','Terminé',NULL,'Terminato',NULL,NULL,NULL,NULL,'Окончен');
INSERT INTO k_lu_job_status (id_status,tr_en,tr_es,tr_fr,tr_de,tr_it,tr_u1,tr_u2,tr_u3,tr_u4,tr_ru) VALUES (1,'Pending','Pendiente','En Suspens',NULL,'Pendente',NULL,NULL,NULL,NULL,'Ожидание');
INSERT INTO k_lu_job_status (id_status,tr_en,tr_es,tr_fr,tr_de,tr_it,tr_u1,tr_u2,tr_u3,tr_u4,tr_ru) VALUES (2,'Suspend','Suspendido','Suspendu',NULL,'Sospeso',NULL,NULL,NULL,NULL,'Приостановлен');
INSERT INTO k_lu_job_status (id_status,tr_en,tr_es,tr_fr,tr_de,tr_it,tr_u1,tr_u2,tr_u3,tr_u4,tr_ru) VALUES (3,'Running','En ejecución','En Cours',NULL,'In esecuzione',NULL,NULL,NULL,NULL,'В действии');
INSERT INTO k_lu_job_status (id_status,tr_en,tr_es,tr_fr,tr_de,tr_it,tr_u1,tr_u2,tr_u3,tr_u4,tr_ru) VALUES (4,'Interrupted','Interrumpido','Interrompu',NULL,'Interrotto',NULL,NULL,NULL,NULL,'прерывать');

